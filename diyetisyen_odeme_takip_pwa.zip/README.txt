DİYETİSYEN ÖDEME TAKİP - PWA

Bu klasör internetsiz çalışabilen PWA kaynak dosyalarını içerir.

Önemli:
PWA'nın service worker özelliği file:// üzerinden doğrudan çalışmaz. İlk kurulum için dosyaların HTTPS üzerinden servis edilmesi gerekir. Bir kez açıldıktan sonra önbelleğe alınan uygulama internetsiz çalışabilir.

Kullanım:
1) Dosyaları bir HTTPS web alanına yükleyin.
2) Android Chrome veya iPhone Safari ile siteyi açın.
3) "Ana ekrana ekle" seçeneğini kullanın.
4) Uygulama telefon ekranında bağımsız açılır.

Veriler localStorage'da cihazda tutulur; sunucuya gönderilmez.
