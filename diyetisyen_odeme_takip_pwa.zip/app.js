const KEY="dietisyen_pwa_patients_v1";
const days=["Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi","Pazar"];
let patients=JSON.parse(localStorage.getItem(KEY)||"[]"), editing=null;
const $=id=>document.getElementById(id);
days.forEach((d,i)=>$("day").insertAdjacentHTML("beforeend",`<option value="${i+1}">${d}</option>`));

function monday(d=new Date()){d=new Date(d.getFullYear(),d.getMonth(),d.getDate());d.setDate(d.getDate()-(d.getDay()||7)+1);return d}
function key(d){return d.toISOString().slice(0,10)}
function state(p){
 const m=monday(), paid=(p.paidWeeks||[]).includes(key(m));
 if(paid)return ["Ödendi","green"];
 const due=new Date(m);due.setDate(due.getDate()+p.day-1);
 const diff=Math.floor((new Date(new Date().toDateString())-new Date(due.toDateString()))/86400000);
 return diff>3?["Gecikti","red"]:["Bekliyor","orange"];
}
function saveAll(){localStorage.setItem(KEY,JSON.stringify(patients));render()}
function render(){
 $("count").textContent=patients.length;
 let pending=0,late=0,total=0; patients.forEach(p=>{const s=state(p)[0];if(s==="Bekliyor")pending++;if(s==="Gecikti")late++;total+=Number(p.fee)||0});
 $("pending").textContent=pending;$("late").textContent=late;$("total").textContent=Math.round(total).toLocaleString("tr-TR")+" TL";
 const list=$("list");list.innerHTML="";
 if(!patients.length){list.innerHTML='<div class="empty">Henüz hasta eklenmedi.<br><br>+ Hasta butonundan ilk kaydı oluştur.</div>';return}
 patients.forEach(p=>{
  const s=state(p), initial=(p.name||"?").trim()[0]?.toUpperCase()||"?";
  const el=document.createElement("div");el.className="card";
  el.innerHTML=`<div class="avatar">${initial}</div><div class="info"><div class="name">${esc(p.name)}</div><div class="sub">${Number(p.fee).toLocaleString("tr-TR")} TL / hafta · ${days[p.day-1]}</div><div class="status ${s[1]}">● ${s[0]}</div></div><button class="menu">⋮</button>`;
  el.querySelector(".menu").onclick=()=>menu(p);
  list.appendChild(el);
 });
}
function menu(p){
 const choice=prompt(`${p.name}\n\n1 = Ödeme Alındı\n2 = Düzenle\n3 = Sil`);
 if(choice==="1"){p.paidWeeks=p.paidWeeks||[];const k=key(monday());if(!p.paidWeeks.includes(k))p.paidWeeks.push(k);saveAll()}
 if(choice==="2")openForm(p);
 if(choice==="3"&&confirm("Hasta silinsin mi?")){patients=patients.filter(x=>x.id!==p.id);saveAll()}
}
function openForm(p=null){
 editing=p;$("modalTitle").textContent=p?"Hasta Düzenle":"Hasta Ekle";
 $("name").value=p?.name||"";$("phone").value=p?.phone||"";$("fee").value=p?.fee||"";$("day").value=p?.day||1;$("note").value=p?.note||"";
 $("modal").classList.remove("hidden");$("name").focus()
}
function closeForm(){$("modal").classList.add("hidden");editing=null}
$("addBtn").onclick=()=>openForm();$("close").onclick=closeForm;$("cancel").onclick=closeForm;
$("save").onclick=()=>{
 const name=$("name").value.trim(), fee=parseFloat($("fee").value.replace(",","."));
 if(!name||!fee||fee<=0){alert("Ad soyad ve geçerli bir ücret gir.");return}
 const p=editing||{id:Date.now().toString(),paidWeeks:[]};
 Object.assign(p,{name,phone:$("phone").value.trim(),fee,day:Number($("day").value),note:$("note").value.trim()});
 if(!editing)patients.push(p);saveAll();closeForm()
};
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
render();
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js"));
